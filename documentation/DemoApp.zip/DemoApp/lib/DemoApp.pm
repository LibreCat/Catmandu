package DemoApp;

use Catmandu -load;
use Catmandu::Sane;
use Catmandu::Util qw(:is :array);

use Dancer ':syntax';

our $VERSION = '0.1';

sub store {
    state $bag = Catmandu->store('default')->bag;
}

sub importer {
    my $file = $_[0];

    Catmandu->importer('default', file => $file);
}

get '/' => sub {
    template 'index';
};

get '/upload' => sub {
    template 'upload';
};

post '/upload' => sub {
    my $file = request->upload('file');

    store->delete_all;

    store->add_many( importer($file->tempname) );

    store->commit;

    redirect '/';
};

get '/search' => sub {
    template 'search';
};

get '/results' => sub {
     my $q     = param "q";
     my $start = param "start" // 0;
     my $limit = 5;

     my $results = [];

     if ($q) {
        $results = store->search(query => $q, start => $start, limit => $limit);
     }

     template 'results' , { q => $q , results => $results };
};

true;
